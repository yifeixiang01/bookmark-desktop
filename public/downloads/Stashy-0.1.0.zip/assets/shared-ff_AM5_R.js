const n="https://bookmark.yifeixiang.com.cn";function o(t){try{return!!t&&["https:","http:"].includes(new URL(t).protocol)}catch{return!1}}export{n as S,o as i};
